-- MySQL dump 10.16  Distrib 10.1.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: a46003081c
-- ------------------------------------------------------
-- Server version	10.1.12-MariaDB-1~trusty

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tabWidget`
--

DROP TABLE IF EXISTS `tabWidget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWidget` (
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT '0',
  `parent` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT '0',
  `title` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `widget_name` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disabled` int(1) NOT NULL DEFAULT '0',
  `chart_type` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_color` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `height` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWidget`
--

LOCK TABLES `tabWidget` WRITE;
/*!40000 ALTER TABLE `tabWidget` DISABLE KEYS */;
INSERT INTO `tabWidget` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `title`, `widget_name`, `disabled`, `chart_type`, `type`, `report`, `background_color`, `width`, `height`) VALUES ('WID-00001','2016-06-02 15:05:33.720307','2016-06-04 15:07:44.873347','Administrator','Administrator',0,NULL,NULL,NULL,0,'Top Ten','Top Ten',0,'','Tab',NULL,NULL,NULL,''),('WID-00002','2016-06-02 15:09:59.349802','2016-06-04 15:05:39.365335','Administrator','Administrator',0,NULL,NULL,NULL,0,'Open Order Status','Open Order Status',0,'','Tab',NULL,NULL,'','200px'),('WID-00003','2016-06-02 15:13:42.406473','2016-06-04 15:09:59.970921','Administrator','Administrator',0,NULL,NULL,NULL,0,'Ageing - Open Order','Ageing - Open Order',0,'','Table','WR-00005',NULL,'',''),('WID-00004','2016-06-02 15:14:28.174940','2016-06-04 15:05:47.992394','Administrator','Administrator',0,NULL,NULL,NULL,0,'Summary Sales','Summary Sales',0,'Pie','Chart','WR-00003',NULL,NULL,'200px');
/*!40000 ALTER TABLE `tabWidget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWidget Report`
--

DROP TABLE IF EXISTS `tabWidget Report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWidget Report` (
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT '0',
  `parent` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT '0',
  `query` longtext COLLATE utf8mb4_unicode_ci,
  `type` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_name` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWidget Report`
--

LOCK TABLES `tabWidget Report` WRITE;
/*!40000 ALTER TABLE `tabWidget Report` DISABLE KEYS */;
INSERT INTO `tabWidget Report` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `query`, `type`, `report_name`, `title`) VALUES ('status-open-order-company','2016-06-02 14:25:42.804080','2016-06-02 14:25:42.804080','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    `tabOpportunity`.`company` AS `Company`,\n    COUNT(1) AS `Total`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Open\') THEN 1\n        ELSE 0\n    END)) AS `Open`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Converted\') THEN 1\n        ELSE 0\n    END)) AS `Converted`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Completed\') THEN 1\n        ELSE 0\n    END)) AS `Completed`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` NOT IN (\'Open\', \'Converted\', \'Completed\')) THEN 1\n        ELSE 0\n    END)) AS `Other`\n	\nFROM\n    `tabOpportunity`\nWHERE fiscal_year = 2016\nGROUP BY `tabOpportunity`.`company`\nORDER BY Total DESC;','Table','Status Open Order Company','Status Open Order Company'),('top-ten-customer','2016-06-02 14:16:01.069049','2016-06-02 14:16:01.069049','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    customer as Customer,\n    CAST(FORMAT((SUM(base_grand_total) / 1000),\n            2)\n        AS DECIMAL (10 , 2 )) AS Revenue\nFROM\n    `tabSales Invoice`\nWHERE\n    docstatus = 1\nAND YEAR(posting_date) = \'2016\'\nGROUP BY customer\nORDER BY Revenue DESC\nLIMIT 10;','Table','Top Ten Customer','Top Ten Customer'),('top-ten-item-qty','2016-06-02 14:20:00.416938','2016-06-02 14:20:00.416938','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    inv_item.item_name as Item,\n    SUM(inv_item.qty) AS Qty\nFROM\n    `tabSales Invoice Item` AS inv_item \nINNER JOIN `tabSales Invoice` AS inv ON (inv.name = inv_item.parent)\nWHERE\n    inv.docstatus = 1\nAND YEAR(inv.posting_date) = \'2016\'\nGROUP BY inv_item.item_code\nORDER BY Qty DESC\nLIMIT 10;','Table','Top Ten Item Qty','Top Ten Item Qty'),('top-ten-item-revenue','2016-06-02 14:23:59.065373','2016-06-02 16:20:07.748887','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    inv_item.item_name as Item,\n    CAST(FORMAT((SUM(inv_item.base_amount) / 1000),\n            2)\n        AS DECIMAL (10 , 2 )) AS Revenue\nFROM\n    `tabSales Invoice Item` AS inv_item\nINNER JOIN `tabSales Invoice` AS inv ON (inv.name = inv_item.parent)\nWHERE\n    inv.docstatus = 1\nAND YEAR(inv.posting_date) = \'2016\'\nGROUP BY inv_item.item_name\nORDER BY Revenue DESC\nLIMIT 10;','Table','Top Ten Item Revenue','Top Ten Item Revenue'),('top-ten-supplier','2016-06-02 13:38:59.628848','2016-06-02 13:38:59.628848','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    supplier as Supplier,\n    CAST(FORMAT((SUM(base_grand_total) / 1000),\n            2)\n        AS DECIMAL (10 , 2 )) AS Revenue\nFROM\n    `tabPurchase Invoice`\nWHERE\n    docstatus = 1\n        AND YEAR(posting_date) = \'2016\'\nGROUP BY supplier\nORDER BY Revenue DESC\nLIMIT 10;','Table','Top Ten Supplier','Top Ten Supplier'),('WR-00001','2016-06-02 14:35:36.215599','2016-06-02 14:35:36.215599','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    `tabOpportunity`.`customer` AS `Customer`,\n    COUNT(1) AS `Total`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Open\') THEN 1\n        ELSE 0\n    END)) AS `Open`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Converted\') THEN 1\n        ELSE 0\n    END)) AS `Converted`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Completed\') THEN 1\n        ELSE 0\n    END)) AS `Completed`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` NOT IN (\'Open\', \'Converted\', \'Completed\')) THEN 1\n        ELSE 0\n    END)) AS `Other`\nFROM\n    `tabOpportunity`\nWHERE fiscal_year = 2016\nGROUP BY `tabOpportunity`.`customer`\nORDER BY Total DESC;','Table','Status Open Order Customer','Status Open Order Customer'),('WR-00002','2016-06-02 14:36:33.419207','2016-06-02 14:36:33.419207','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    `tabOpportunity`.`territory` AS `Territory`,\n    COUNT(1) AS `Total`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Open\') THEN 1\n        ELSE 0\n    END)) AS `Open`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Converted\') THEN 1\n        ELSE 0\n    END)) AS `Converted`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` = \'Completed\') THEN 1\n        ELSE 0\n    END)) AS `Completed`,\n    SUM((CASE\n        WHEN (`tabOpportunity`.`status` NOT IN (\'Open\', \'Converted\', \'Completed\')) THEN 1\n        ELSE 0\n    END)) AS `Other`\nFROM\n    `tabOpportunity`\nWHERE fiscal_year = 2016\nGROUP BY `tabOpportunity`.`territory`\nORDER BY Total DESC;','Table','Status Open Order Territory','Status Open Order Territory'),('WR-00003','2016-06-02 14:41:08.000667','2016-06-02 14:41:08.000667','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    SUBSTRING(MONTHNAME(posting_date), 1, 3) AS label,\n    CAST(FORMAT((SUM(base_grand_total) / 1000), 2) AS DECIMAL (10 , 2 )) AS data\nFROM\n    `tabSales Invoice`\nWHERE\n    docstatus = 1\nAND fiscal_year = \'2016\'\n-- YEAR(posting_date) = \'2016\'\nGROUP BY MONTHNAME(posting_date)\nORDER BY MONTH(posting_date);','Chart','Summary Monthly Sales','Summary Monthly Sales'),('WR-00004','2016-06-02 14:41:41.701922','2016-06-02 15:14:42.653027','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    SUBSTRING(MONTHNAME(posting_date), 1, 3) AS label,\n    CAST(FORMAT((SUM(base_grand_total) / 1000), 2) AS DECIMAL (10 , 2 )) AS data\nFROM\n    `tabPurchase Invoice`\nWHERE\n    docstatus = 1\nAND fiscal_year = \'2016\'\n-- YEAR(posting_date) = \'2016\'\nGROUP BY MONTHNAME(posting_date)\nORDER BY MONTH(posting_date);','Chart','Summary Monthly Purchase','Summary Monthly Purchase'),('WR-00005','2016-06-02 14:51:33.179182','2016-06-02 14:51:33.179182','Administrator','Administrator',0,NULL,NULL,NULL,0,'SELECT \n    so.customer AS \'Client\',\n    COUNT(1) AS \'Total\',\n    SUM(CASE\n        WHEN DATEDIFF(CURDATE(), so_item.delivery_due_date) > 0 THEN 1\n        ELSE 0\n    END) AS \'Late\',\n    CONCAT(FORMAT((SUM(CASE\n                    WHEN DATEDIFF(CURDATE(), so_item.delivery_due_date) > 0 THEN 1\n                    ELSE 0\n                END) / COUNT(1) * 100),\n                2),\n            \'%\') AS \'%\',\n    SUM(CASE\n        WHEN\n            (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 0\n                AND DATEDIFF(CURDATE(), so_item.delivery_due_date) < 7)\n        THEN\n            1\n        ELSE 0\n    END) AS \'< 7\',\n    SUM(CASE\n        WHEN\n            (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 6\n                AND DATEDIFF(CURDATE(), so_item.delivery_due_date) < 31)\n        THEN\n            1\n        ELSE 0\n    END) AS \'7-29\',\n    SUM(CASE\n        WHEN\n            (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 31\n                AND DATEDIFF(CURDATE(), so_item.delivery_due_date) < 61)\n        THEN\n            1\n        ELSE 0\n    END) AS \'30-59\',\n    SUM(CASE\n        WHEN\n            (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 60\n                AND DATEDIFF(CURDATE(), so_item.delivery_due_date) < 91)\n        THEN\n            1\n        ELSE 0\n    END) AS \'60-89\',\n    SUM(CASE\n        WHEN\n            (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 90\n                AND DATEDIFF(CURDATE(), so_item.delivery_due_date) < 121)\n        THEN\n            1\n        ELSE 0\n    END) AS \'90-119\',\n    SUM(CASE\n        WHEN (DATEDIFF(CURDATE(), so_item.delivery_due_date) > 120) THEN 1\n        ELSE 0\n    END) AS \'120+\'\nFROM\n    `tabSales Order` AS so\nINNER JOIN\n    `tabSales Order Item` AS so_item ON (so_item.parent = so.name)\nLEFT JOIN\n		(SELECT \n				dn_item.item_code,\n				dn_item.item_name,\n				dn_item.description,\n				dn_item.number,\n                dn_item.modified,\n				dn_item.against_sales_order,\n				dn_item.qty\n		FROM\n			`tabDelivery Note Item` AS dn_item\n		WHERE\n			dn_item.docstatus = 1\n		) AS dn_item ON (\n						dn_item.against_sales_order = so_item.parent\n						AND dn_item.item_code = so_item.item_code\n						AND dn_item.item_name = so_item.item_name\n						AND dn_item.description = so_item.description\n						AND dn_item.number <=> so_item.number\n                        AND dn_item.modified > so_item.delivery_due_date\n					)\nWHERE\nso.status IN (\'To Deliver and Bill\' , \'To Deliver\', \'Draft\')\nAND (dn_item.qty IS NULL OR dn_item.qty < so_item.qty)\nAND so.fiscal_year = \'2016\'\nGROUP BY so.customer\nORDER BY so.customer','Table','Ageing Open Order Customer','Ageing Open Order Customer');
/*!40000 ALTER TABLE `tabWidget Report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWidget Role`
--

DROP TABLE IF EXISTS `tabWidget Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWidget Role` (
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT '0',
  `parent` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT '0',
  `role` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWidget Role`
--

LOCK TABLES `tabWidget Role` WRITE;
/*!40000 ALTER TABLE `tabWidget Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWidget Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWidget Tab`
--

DROP TABLE IF EXISTS `tabWidget Tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWidget Tab` (
  `name` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT '0',
  `parent` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT '0',
  `tab_name` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWidget Tab`
--

LOCK TABLES `tabWidget Tab` WRITE;
/*!40000 ALTER TABLE `tabWidget Tab` DISABLE KEYS */;
INSERT INTO `tabWidget Tab` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `tab_name`, `title`, `report`) VALUES ('TAB-0001','2016-06-02 15:05:33.720307','2016-06-04 15:07:44.873347','Administrator','Administrator',0,'WID-00001','tabs','Widget',1,'Customer',NULL,'top-ten-customer'),('TAB-0002','2016-06-02 15:05:33.720307','2016-06-04 15:07:44.873347','Administrator','Administrator',0,'WID-00001','tabs','Widget',2,'Supplier',NULL,'top-ten-supplier'),('TAB-0004','2016-06-02 15:05:33.720307','2016-06-04 15:07:44.873347','Administrator','Administrator',0,'WID-00001','tabs','Widget',3,'Item',NULL,'top-ten-item-revenue'),('TAB-0005','2016-06-02 15:09:59.349802','2016-06-04 15:05:39.365335','Administrator','Administrator',0,'WID-00002','tabs','Widget',1,'Customer',NULL,'WR-00001'),('TAB-0006','2016-06-02 15:09:59.349802','2016-06-04 15:05:39.365335','Administrator','Administrator',0,'WID-00002','tabs','Widget',2,'Territory',NULL,'WR-00002'),('TAB-0007','2016-06-02 15:09:59.349802','2016-06-04 15:05:39.365335','Administrator','Administrator',0,'WID-00002','tabs','Widget',3,'Company',NULL,'status-open-order-company');
/*!40000 ALTER TABLE `tabWidget Tab` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `tabDocField`
--

LOCK TABLES `tabDocField` WRITE;
/*!40000 ALTER TABLE `tabDocField` DISABLE KEYS */;
INSERT INTO `tabDocField` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `fieldname`, `label`, `oldfieldname`, `fieldtype`, `oldfieldtype`, `options`, `search_index`, `hidden`, `set_only_once`, `print_hide`, `report_hide`, `reqd`, `bold`, `collapsible`, `unique`, `no_copy`, `allow_on_submit`, `trigger`, `collapsible_depends_on`, `depends_on`, `permlevel`, `ignore_user_permissions`, `width`, `print_width`, `default`, `description`, `in_filter`, `in_list_view`, `read_only`, `precision`, `length`, `print_hide_if_no_value`) VALUES ('0737e4b163','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',15,'background_color','Background Color',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('0b3c535b24','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',11,'section_break_roles','Roles',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('0f71c07117','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',3,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,0,'',0,0),('309d76ec25','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',6,'chart_type','Chart Type',NULL,'Select',NULL,'\nPie\nLine',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('4d7a0c3bfd','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',13,'section_break_css','CSS Style',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('59e8cb2e29','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',5,'type','Type',NULL,'Select',NULL,'Table\nTab\nChart',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,0,'',0,0),('64bad868d0','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',9,'section_break_tab','Tabs',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('728e0f52ef','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',1,'widget_name','Widget Name',NULL,'Data',NULL,NULL,0,0,0,0,0,1,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('752ac3d4b2','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',16,'height','Height',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,'',NULL,0,0,0,'',0,0),('8bd6bcb0a2','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',8,'report','Report',NULL,'Link',NULL,'Widget Report',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('928d48edc1','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',12,'roles','Roles',NULL,'Table',NULL,'Widget Role',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('983b355256','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',2,'title','Title',NULL,'Data',NULL,'{widget_name}',0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('9c35f3b4b3','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',4,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('a457cc2ef1','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',14,'width','Width',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,'','Width of widget (e.g. 200px or 50%)',0,0,0,'',0,0),('b529ccca91','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',10,'tabs','Tab',NULL,'Table',NULL,'Widget Tab',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('f94633665c','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','fields','DocType',7,'section_break_report','Report',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('2ad135ec66','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,'Widget Report','fields','DocType',2,'type','Type',NULL,'Select',NULL,'Table\nChart',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,0,'',0,0),('8b866b4077','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,'Widget Report','fields','DocType',3,'query','Query',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('aae09b74d8','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,'Widget Report','fields','DocType',4,'title','Title',NULL,'Data',NULL,'{report_name}',0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('dda6d4d836','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,'Widget Report','fields','DocType',1,'report_name','Report Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('e47bdc66e3','2016-05-30 10:01:18.780553','2016-05-30 10:01:18.780553','Administrator','Administrator',0,'Widget Role','fields','DocType',1,'role','Role',NULL,'Link',NULL,'Role',0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('f855ba0c99','2016-05-30 09:59:10.663474','2016-06-02 14:57:47.515918','Administrator','Administrator',0,'Widget Tab','fields','DocType',2,'report','Report',NULL,'Link',NULL,'Widget Report',0,0,0,0,0,1,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0),('fd4071eb7d','2016-05-30 09:59:10.663474','2016-06-02 14:57:47.515918','Administrator','Administrator',0,'Widget Tab','fields','DocType',1,'tab_name','Tab Name',NULL,'Data',NULL,NULL,0,0,0,0,0,1,0,0,0,0,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,0,'',0,0);
/*!40000 ALTER TABLE `tabDocField` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `tabDocPerm`
--

LOCK TABLES `tabDocPerm` WRITE;
/*!40000 ALTER TABLE `tabDocPerm` DISABLE KEYS */;
INSERT INTO `tabDocPerm` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `permlevel`, `role`, `match`, `read`, `write`, `create`, `submit`, `cancel`, `delete`, `amend`, `report`, `export`, `import`, `share`, `print`, `email`, `user_permission_doctypes`, `set_user_permissions`, `apply_user_permissions`, `if_owner`) VALUES ('8e4db348be','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,'Widget','permissions','DocType',1,0,'All',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,NULL,0,0,0),('049a83bdb3','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,'Widget Report','permissions','DocType',1,0,'All',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,NULL,0,0,0);
/*!40000 ALTER TABLE `tabDocPerm` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `tabDocType`
--

LOCK TABLES `tabDocType` WRITE;
/*!40000 ALTER TABLE `tabDocType` DISABLE KEYS */;
INSERT INTO `tabDocType` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `search_fields`, `issingle`, `istable`, `module`, `app`, `autoname`, `name_case`, `title_field`, `sort_field`, `sort_order`, `description`, `colour`, `read_only`, `in_create`, `menu_index`, `parent_node`, `smallicon`, `allow_copy`, `allow_rename`, `allow_import`, `hide_toolbar`, `hide_heading`, `max_attachments`, `print_outline`, `read_only_onload`, `in_dialog`, `document_type`, `icon`, `tag_fields`, `subject`, `_last_update`, `default_print_format`, `is_submittable`, `_user_tags`, `custom`) VALUES ('Widget','2016-05-30 10:13:46.109788','2016-06-04 15:07:01.315760','Administrator','Administrator',0,NULL,NULL,NULL,0,'title, type',0,0,'Dashboard',NULL,'WID-.#####','','title','modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,0,0,'Document',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Widget Report','2016-05-30 11:07:00.289913','2016-06-02 14:35:01.207336','Administrator','Administrator',0,NULL,NULL,NULL,0,'report_name, type',0,0,'Dashboard',NULL,'WR-.#####','','title','modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,0,0,'Document',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Widget Role','2016-05-30 10:01:18.780553','2016-05-30 10:01:18.780553','Administrator','Administrator',0,NULL,NULL,NULL,0,NULL,0,1,'Dashboard',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,0,0,'Document',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Widget Tab','2016-05-30 09:59:10.663474','2016-06-02 14:57:47.515918','Administrator','Administrator',0,NULL,NULL,NULL,0,'tab_name, report',0,1,'Dashboard',NULL,'TAB-.####','','tab_name','modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,0,0,'Document',NULL,NULL,NULL,NULL,NULL,0,NULL,0);
/*!40000 ALTER TABLE `tabDocType` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `tabModule Def`
--

LOCK TABLES `tabModule Def` WRITE;
/*!40000 ALTER TABLE `tabModule Def` DISABLE KEYS */;
INSERT INTO `tabModule Def` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `module_name`, `app_name`) VALUES ('Dashboard','2016-05-23 20:01:04.208925','2016-05-23 20:01:04.208925','Administrator','Administrator',0,NULL,NULL,NULL,0,'Dashboard','dashboard');
/*!40000 ALTER TABLE `tabModule Def` ENABLE KEYS */;
UNLOCK TABLES;

ed_cs_client */;

--
-- Dumping data for table `tabPage`
--

LOCK TABLES `tabPage` WRITE;
/*!40000 ALTER TABLE `tabPage` DISABLE KEYS */;
INSERT INTO `tabPage` (`name`, `creation`, `modified`, `modified_by`, `owner`, `docstatus`, `parent`, `parentfield`, `parenttype`, `idx`, `title`, `module`, `standard`, `page_name`, `icon`) VALUES ('dashboard','2016-05-23 15:45:35.124068','2016-05-23 15:45:35.124068','Administrator','Administrator',0,NULL,NULL,NULL,0,'Dashboard','Dashboard','Yes','Dashboard',NULL);
/*!40000 ALTER TABLE `tabPage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-04 17:35:24
